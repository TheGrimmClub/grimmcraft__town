execute if score timer Feuerwerk matches 80 run summon firework_rocket ~5 ~1 ~ {LifeTime:45,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:3,explosions:[{shape:"burst",colors:[I;160],fade_colors:[I;14544639],has_twinkle:0,has_trail:0}]}}}}

execute if score timer Feuerwerk matches 60 run summon firework_rocket ~10 ~1 ~ {LifeTime:45,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:3,explosions:[{shape:"burst",colors:[I;160],fade_colors:[I;14544639],has_twinkle:0,has_trail:0}]}}}}

execute if score timer Feuerwerk matches 40 run summon firework_rocket ~5 ~1 ~ {LifeTime:45,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:3,explosions:[{shape:"burst",colors:[I;160],fade_colors:[I;14544639],has_twinkle:0,has_trail:0}]}}}}

execute if score timer Feuerwerk matches 20 run summon firework_rocket ~10 ~1 ~ {LifeTime:45,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:3,explosions:[{shape:"burst",colors:[I;160],fade_colors:[I;14544639],has_twinkle:0,has_trail:0}]}}}}

execute if score timer Feuerwerk matches 0 run summon firework_rocket ~5 ~1 ~ {LifeTime:45,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:3,explosions:[{shape:"burst",colors:[I;160],fade_colors:[I;14544639],has_twinkle:0,has_trail:0}]}}}}

